#include <stdio.h>

int main() {
    printf("Zdravo, kako si?\n");
    return 0;
}

