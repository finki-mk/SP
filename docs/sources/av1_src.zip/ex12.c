#include <stdio.h>

int main() {
    printf("Zdravo, kako si?\n");
    // dodadi go ovoj red
    printf("Neshto ne ti se pravi muabet?\n");
    return 0;
}
