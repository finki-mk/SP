#include <stdio.h>

int main() {
    printf("Hi, how are you?\n");
    return 0;
}

