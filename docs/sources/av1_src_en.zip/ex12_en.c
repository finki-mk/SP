#include <stdio.h>

int main() {
    printf("Hi, how are you doing?\n");
    // add this following line
    printf("So, yo're not in the mood for talking?\n");
    return 0;
}
