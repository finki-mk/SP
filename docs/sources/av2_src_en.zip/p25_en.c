#include <stdio.h>

int main() {
    int a = 19;
    printf("The residue of division with 2 is: %d\n", a % 2);
    printf("The residue of division with 3 is: %d\n", a % 3);
    printf("The residue of division with 5 is: %d\n", a % 5);
    printf("The residue of division with 8 is: %d\n", a % 8);
    return 0;
}
