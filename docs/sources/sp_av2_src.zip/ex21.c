#include <stdio.h>

// glavna funkcija
int main() {
    /*
    pechatenje poraka na ekran
    */
    printf("Dobredojdovte na FINKI!\n");
    return 0;
}
