#include <stdio.h>

int main() {
    const long double PI = 3.141592653590L;
    const int DENOVI_VO_NEDELA = 7;
    const NEDELA = 0; // po default int
    DENOVI_VO_NEDELA = 7; // greshka
    return 0;
}
