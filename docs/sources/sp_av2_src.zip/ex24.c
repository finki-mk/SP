#include <stdio.h>
#define PI 3.141592653590L
#define DENOVI_VO_NEDELA 7
#define NEDELA 0

int main() {
    long broj = PI;
    int den = NEDELA;
    return 0;
}
