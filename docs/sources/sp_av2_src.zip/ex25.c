#include <stdio.h>

int main() {
    printf("Prva rechenica.\n");
    printf("Vtora rechenica.\nTreta rechenica.");
    return 0;
}
