#include <iostream>
using namespace std;

int main() {
    int x = 7;
    cout << "Brojot " << x << " na kvadrat e " << x * x << endl;
    return 0;
}
