#include <stdio.h>

int main() {
    int a = 3;
    int b = 5;
    int c = 12;
    float as = (a + b + c) / 3.0;
    printf("Aritmetichkata sredina e %2.f\n", as);
    return 0;
}
