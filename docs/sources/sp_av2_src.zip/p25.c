#include <stdio.h>

int main() {
    int a = 19;
    printf("Ostatokot pri delenje so 2 e: %d\n", a % 2);
    printf("Ostatokot pri delenje so 3 e: %d\n", a % 3);
    printf("Ostatokot pri delenje so 5 e: %d\n", a % 5);
    printf("Ostatokot pri delenje so 8 e: %d\n", a % 8);
    return 0;
}
