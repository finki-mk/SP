#include <stdio.h>
#define PI 3.141592653590L
#define DAYS_IN_WEEKS 7
#define SUNDAY 0

int main() {
    long number = PI;
    int day = SUNDAY;
    return 0;
}
