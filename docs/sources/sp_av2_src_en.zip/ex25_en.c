#include <stdio.h>

int main() {
    printf("First sentence.\n");
    printf("Second sentence.\nThird sentence.\n");
    return 0;
}
