#include <stdio.h>

int main() {
    printf(" is a word long %d letters.\n", printf("Macedonia"));
    return 0;
}
